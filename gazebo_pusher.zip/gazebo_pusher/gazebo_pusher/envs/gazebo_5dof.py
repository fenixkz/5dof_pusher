from __future__ import print_function
import gym
import rospy
import tf
import roslaunch
import time
import numpy as np
import tf


from gym import utils, spaces
from geometry_msgs.msg import Twist
from std_msgs.msg import Float64
from std_msgs.msg import Bool
from std_srvs.srv import Empty
from sensor_msgs.msg import JointState
from gym.utils import seeding
from gazebo_msgs.msg import ModelState
from gazebo_msgs.msg import ModelStates
from gazebo_msgs.srv import SetModelState
from gazebo_msgs.msg import ContactsState
from gazebo_msgs.srv import GetLinkState

def callback(data):
	angle = data.position

def rad2deg(ang):
    return ang*180/3.14

def deg2rad(ang):
    return ang*3.14/180



class GazeboPlanar5DofEnv(gym.Env):
	def __init__(self):
		print("Created an environment")
		rospy.init_node('rl_gym')
		self.motor1_pub = rospy.Publisher('/robot/joint1_position_controller/command', Float64, queue_size=5)
		self.motor2_pub = rospy.Publisher('/robot/joint2_position_controller/command', Float64, queue_size=5)
		self.motor3_pub = rospy.Publisher('/robot/joint3_position_controller/command', Float64, queue_size=5)
		self.motor4_pub = rospy.Publisher('/robot/joint4_position_controller/command', Float64, queue_size=5)
		self.motor5_pub = rospy.Publisher('/robot/joint5_position_controller/command', Float64, queue_size=5)

		self.action_space = spaces.Discrete(10) #F,L,R
		self.reward_range = (-np.inf, np.inf)
		quaternion = tf.transformations.quaternion_from_euler(0.000338, 0.003608, 0.000875)
		self.box = ModelState()
		self.box.model_name = 'robot1'
		self.box.pose.position.x = -2.873680
		self.box.pose.position.y = -0.128694
		self.box.pose.position.z = 0.012142
		self.box.pose.orientation.x = quaternion[0]
		self.box.pose.orientation.y = quaternion[1]
		self.box.pose.orientation.z = quaternion[2]
		self.box.pose.orientation.w = quaternion[3]
		self.box.reference_frame = 'world'
		self.msg = [1.7564973394647119, -0.8303822610535567, -1.670635381665238, -0.8979926220318672, 1.642187184591668]
		self.pos_old = 5 - 2.87
		self._seed()



	def _seed(self, seed=None):
		self.np_random, seed = seeding.np_random(seed)
		return [seed]


	def step(self, action):

		angles = None
		while angles is None:
			try:
				angles = rospy.wait_for_message('/robot/joint_states', JointState, timeout=5)
			except:
				pass
		rate = rospy.Rate(50)
		if action == 0: #Base motor left
			msg = angles.position[4] - deg2rad(5)
			while True:
				self.motor1_pub.publish(Float64(msg))
				s = rospy.wait_for_message('/robot/joint_states', JointState, timeout = 5)
				#print(msg)
				#print(s.position)
				if (abs(s.position[4] - msg) < 0.01):
					break
				rate.sleep()


		elif action == 1: #Base motor right
			msg = angles.position[4] + deg2rad(5)
			while True:
				self.motor1_pub.publish(Float64(msg))
				s = rospy.wait_for_message('/robot/joint_states', JointState, timeout = 5)
				#print(msg)
				#print(s.position)
				if (abs(s.position[4] - msg) < 0.01):
					break
				rate.sleep()

		elif action == 2: #Second motor left
			msg = angles.position[1] - deg2rad(5)
			while True:
				self.motor2_pub.publish(Float64(msg))
				s = rospy.wait_for_message('/robot/joint_states', JointState, timeout = 5)
				#print(msg)
				#print(s.position)
				if (abs(s.position[1] - msg) < 0.01):
					break
				rate.sleep()

		elif action == 3: #Second motor right
			msg = angles.position[1] + deg2rad(5)
			while True:
				self.motor2_pub.publish(Float64(msg))
				s = rospy.wait_for_message('/robot/joint_states', JointState, timeout = 5)
				#print(msg)
				#print(s.position)
				if (abs(s.position[1] - msg) < 0.01):
					break
				rate.sleep()

		elif action == 4: #Third motor left
			msg = angles.position[2] - deg2rad(5)
			while True:
				self.motor3_pub.publish(Float64(msg))
				s = rospy.wait_for_message('/robot/joint_states', JointState, timeout = 5)
				#print(msg)
				#print(s.position)
				if (abs(s.position[2] - msg) < 0.01):
					break
				rate.sleep()

		elif action == 5: #Third motor right
			msg = angles.position[2] + deg2rad(5)
			while True:
				self.motor3_pub.publish(Float64(msg))
				s = rospy.wait_for_message('/robot/joint_states', JointState, timeout = 5)
				#print(msg)
				#print(s.position)
				if (abs(s.position[2] - msg) < 0.01):
					break
				rate.sleep()

		elif action == 6: #Fourth motor left
			msg = angles.position[3] - deg2rad(5)
			while True:
				self.motor4_pub.publish(Float64(msg))
				s = rospy.wait_for_message('/robot/joint_states', JointState, timeout = 5)
				#print(msg)
				#print(s.position)
				if (abs(s.position[3] - msg) < 0.01):
					break
				rate.sleep()

		elif action == 7: #Fourth motor right
			msg = angles.position[3] + deg2rad(5)
			while True:
				self.motor4_pub.publish(Float64(msg))
				s = rospy.wait_for_message('/robot/joint_states', JointState, timeout = 5)
				#print(msg)
				#print(s.position)
				if (abs(s.position[3] - msg) < 0.01):
					break
				rate.sleep()

		elif action == 8: #Fifth motor left
			msg = angles.position[0] - deg2rad(5)
			while True:
				self.motor5_pub.publish(Float64(msg))
				s = rospy.wait_for_message('/robot/joint_states', JointState, timeout = 5)
				#print("!!")
				#print(msg)

				if (abs(s.position[0] - msg) < 0.01):
					break
				rate.sleep()

		elif action == 9: #Fifth motor right
			msg = angles.position[0] + deg2rad(5)
			while True:
				self.motor5_pub.publish(Float64(msg))
				s = rospy.wait_for_message('/robot/joint_states', JointState, timeout = 5)
				#print(msg)
				#print(s.position)
				if (abs(s.position[0] - msg) < 0.01):
					break
				rate.sleep()
		print("!")
		angles = rospy.wait_for_message('/robot/joint_states', JointState, timeout = 5)
		print("!!")

		sensor1 = sensor2 = sensor3 = sensor4 = sensor5 = None
		while  sensor1 is None and sensor2 is None and sensor3 is None and sensor4 is None and sensor5 is None:
			try:
				sensor1 = rospy.wait_for_message('/robot_sensor1', ContactsState, timeout = 5)
				sensor2 = rospy.wait_for_message('/robot_sensor2', ContactsState, timeout = 5)
				sensor3 = rospy.wait_for_message('/robot_sensor3', ContactsState, timeout = 5)
				sensor4 = rospy.wait_for_message('/robot_sensor4', ContactsState, timeout = 5)
				sensor5 = rospy.wait_for_message('/robot_sensor5', ContactsState, timeout = 5)
			except:
				pass

		done = False
		reward = -1



		try:
			aa = rospy.ServiceProxy('/gazebo/get_link_state', GetLinkState)
			a = aa("box","world")
		except rospy.ServiceException as e:
			print("Service call failed: %s"%e)

		for x in angles.position:
			if abs(abs(x)-2) < 0.08:
				done = True
				reward = -50
				print("State is out of range")

		if (abs(a.link_state.pose.position.x - self.pos_old) > 0.02):
			reward = 2
		if (a.link_state.pose.position.x > 2.6):
			reward = 15
		if (a.link_state.pose.position.x > 3):
			reward = 15
		if (sensor1.states == [] and sensor2.states == [] and sensor3.states == [] and sensor4.states == [] and sensor5.states == []):
			done = True
			reward = -50
		elif (a.link_state.pose.position.x > 4):
			done = True
			reward = 80
		print("Old position: "+str(self.pos_old)+" ; now position is: "+str(a.link_state.pose.position.x))
		self.pos_old = a.link_state.pose.position.x
		state = self.states2obs(angles.position)
		return state, reward, done, {}


	def reset(self):
        # Resets the state of the environment and returns an initial observation.

		rate = rospy.Rate(50)
		while True:
			self.motor1_pub.publish(Float64(self.msg[4]))
			self.motor2_pub.publish(Float64(self.msg[1]))
			self.motor3_pub.publish(Float64(self.msg[2]))
			self.motor4_pub.publish(Float64(self.msg[3]))
			self.motor5_pub.publish(Float64(self.msg[0]))
			angles = rospy.wait_for_message('/robot/joint_states', JointState, timeout = 5)
			if (abs(angles.position[4] - self.msg[4]) < 0.01 and abs(angles.position[1] - self.msg[1]) < 0.01 and \
			    abs(angles.position[2] - self.msg[2]) < 0.01 and abs(angles.position[3] - self.msg[3]) < 0.01 and abs(angles.position[0] - self.msg[0]) < 0.01):
				break
			rate.sleep()

		angles = None
		while angles is None:
			try:
				angles = rospy.wait_for_message('/robot/joint_states', JointState, timeout=5)
			except:
				pass
		try:
			set_state = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)
			resp = set_state(self.box)
		except rospy.ServiceException as e:
			print("Service call failed: %s" % e)

		state = self.states2obs(angles.position)
		return state

	def states2obs(self,states):

		angle1 = int(10 + (round(rad2deg(states[4])) + 115)//5)
		angle2 = int(10 + (round(rad2deg(states[1])) + 115)//5)
		angle3 = int(10 + (round(rad2deg(states[2])) + 115)//5)
		angle4 = int(10 + (round(rad2deg(states[3])) + 115)//5)
		angle5 = int(10 + (round(rad2deg(states[0])) + 115)//5)
		c = str(angle1)+str(angle2)+str(angle3)+str(angle4)+str(angle5)
		result = int(c)

		return result
